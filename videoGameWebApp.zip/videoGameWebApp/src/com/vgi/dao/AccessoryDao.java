package com.vgi.dao;

public class AccessoryDao {
	//TODO
//	public List<Accessory> getFilteredAccessories(Map selectedAttributes){
//		//map can be of dynamic size
//		//search in map which filters are to be applied for the SQL query
//		return;
//	}
// 
}
