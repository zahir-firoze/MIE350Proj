package com.vgi.dao;

public class ConsoleDao {

}
