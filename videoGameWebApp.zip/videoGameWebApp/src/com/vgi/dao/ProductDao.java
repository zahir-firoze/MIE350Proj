package com.vgi.dao;

public class ProductDao {
	//TODO
	/*
	public HashMap<Integer,Integer> getProductInventory(int upc){
		return
	}
	*/
}
