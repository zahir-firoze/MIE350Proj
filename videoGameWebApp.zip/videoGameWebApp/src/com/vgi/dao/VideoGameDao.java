package com.vgi.dao;

public class VideoGameDao {

	//TODO
//	public List<VideoGame> getFilteredVideoGames(Map selectedAttributes){
//		//map can be of dynamic size
//		//search in map which filters are to be applied for the SQL query
//		return;
//	}
// 
}
