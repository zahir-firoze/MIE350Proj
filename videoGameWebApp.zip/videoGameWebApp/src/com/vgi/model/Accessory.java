package com.vgi.model;

public class Accessory extends Product {
	
	
	@Override
	public String toString() {
		return "Accessory [" + super.toString() + "]";
	}
}
